<?php

namespace App\Http\Controllers;

use App\Http\Requests\UceniciRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UceniciController extends Controller
{
    public function index(){

        $ucenici=DB::table('ucenici')->get();
        return view('ucenici.index',["ucenici"=>$ucenici]);
    }

    public function create(){
        return view('ucenici.create');
    }
    public function save(UceniciRequest $request){

        $povez=DB::table('povez')->insert([
            'Naziv'=>$request->post('nazivUcenici')
        ]);
        if($povez){
          return redirect()->route('ucenici.index')->with('ok','Ucenik uspjesno dodat');
        }else{
         return redirect()->route('ucenici.index')->with('fail','Ucenik nije uspjesno dodat');
        }
    }  
    public function edit($id){
      $ucenik=DB::table('ucenici')->where('Id',$id)->first();
      return view('ucenici.edit',["pismo"=>$ucenik]);
    } 
    
    public function update(Request $request){
        $request->validate([
            'nazivUceniciEdit'=>'required'
            ]);
            $ucenik=DB::table('ucenici')->where('Id',$request->post('id'))->update([
                'Naziv'=>$request->post('nazivUceniciEdit')
            ]);
            if($ucenik){
              return redirect()->route('ucenici.index')->with('ok','Ucenik uspjesno azuriran');
            }else{
             return redirect()->route('ucenici.index')->with('fail','Ucenik nije uspjesno azuriran');
            }

    } 
     public function delete($id){
         $ucenik=DB::table('ucenici')->where('Id',$id)->delete();
         if($ucenik){
            return redirect()->route('ucenici.index')->with('ok','Ucenik uspjesno obrisan');
          }else{
           return redirect()->route('ucenici.index')->with('fail','Ucenik nije uspjesno obrisan');
          }
    }  
      
}
