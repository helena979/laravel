<?php

namespace App\Http\Controllers;

use App\Http\Requests\FormatRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class FormatController extends Controller
{
    public function index(){

        $format=DB::table('format')->get();
        return view('format.index',["pisma"=>$format]);
    }

    public function create(){
        return view('format.create');
    }
    public function save(FormatRequest $request){

        $format=DB::table('format')->insert([
            'Naziv'=>$request->post('nazivFormat')
        ]);
        if($format){
          return redirect()->route('format.index')->with('ok','Format uspjesno dodat');
        }else{
         return redirect()->route('format.index')->with('fail','Format nije uspjesno dodat');
        }
    }  
    public function edit($id){
      $format=DB::table('format')->where('Id',$id)->first();
      return view('format.edit',["format"=>$format]);
    } 
    
    public function update(Request $request){
        $request->validate([
            'nazivFormatEdit'=>'required'
            ]);
            $format=DB::format('pismo')->where('Id',$request->post('id'))->update([
                'Naziv'=>$request->post('nazivFormatEdit')
            ]);
            if($format){
              return redirect()->route('format.index')->with('ok','Format uspjesno azuriran');
            }else{
             return redirect()->route('format.index')->with('fail','Format nije uspjesno azuriran');
            }

    } 
     public function delete($id){
         $format=DB::table('format')->where('Id',$id)->delete();
         if($format){
            return redirect()->route('format.index')->with('ok','Format uspjesno obrisan');
          }else{
           return redirect()->route('format.index')->with('fail','Format nije uspjesno obrisan');
          }
    }  
      
}
