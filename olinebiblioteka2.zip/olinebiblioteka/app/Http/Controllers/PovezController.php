<?php

namespace App\Http\Controllers;

use App\Http\Requests\PovezRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PovezController extends Controller
{
    public function index(){

        $povez=DB::table('povez')->get();
        return view('povez.index',["povezi"=>$povez]);
    }

    public function create(){
        return view('povez.create');
    }
    public function save(PovezRequest $request){

        $povez=DB::table('povez')->insert([
            'Naziv'=>$request->post('nazivPovez')
        ]);
        if($povez){
          return redirect()->route('povez.index')->with('ok','Povez uspjesno dodat');
        }else{
         return redirect()->route('povez.index')->with('fail','Povez nije uspjesno dodat');
        }
    }  
    public function edit($id){
      $povez=DB::table('povez')->where('Id',$id)->first();
      return view('povez.edit',["pismo"=>$povez]);
    } 
    
    public function update(Request $request){
        $request->validate([
            'nazivPovezEdit'=>'required'
            ]);
            $povez=DB::table('povez')->where('Id',$request->post('id'))->update([
                'Naziv'=>$request->post('nazivPovezEdit')
            ]);
            if($povez){
              return redirect()->route('povez.index')->with('ok','Povez uspjesno azuriran');
            }else{
             return redirect()->route('povez.index')->with('fail','Povez nije uspjesno azuriran');
            }

    } 
     public function delete($id){
         $povez=DB::table('povez')->where('Id',$id)->delete();
         if($povez){
            return redirect()->route('povez.index')->with('ok','Povez uspjesno obrisan');
          }else{
           return redirect()->route('povez.index')->with('fail','Povez nije uspjesno obrisan');
          }
    }  
      
}
