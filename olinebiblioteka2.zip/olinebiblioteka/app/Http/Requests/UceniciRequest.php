<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UceniciRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nazivUcenici'=>'required|max:191'
        ];
    }

    public function messages() {
        return [
            'nazivUcenici.required' => 'Polje naziv ucenika je obavezno',
            'nazivUcenici.max' => 'Maksimalni broj karaktera je 191.'
        ];
    }
}
