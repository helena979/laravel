<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PovezRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nazivPovez'=>'required|max:191'
        ];
    }

    public function messages() {
        return [
            'nazivPovez.required' => 'Polje naziv pisma je obavezno',
            'nazivPovez.max' => 'Maksimalni broj karaktera je 191.'
        ];
    }
}
