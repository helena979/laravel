<?php

use App\Http\Controllers\AuthorController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LibrarianController;
use App\Http\Controllers\PublishingController;
use App\Http\Controllers\Settings\CoverController;
use App\Http\Controllers\Settings\CategoryController;
use App\Http\Controllers\Settings\FormatController;
use App\Http\Controllers\Settings\GenreController;
use App\Http\Controllers\Settings\PolicyController;
use App\Http\Controllers\Settings\PublisherController;
use App\Http\Controllers\Settings\AlphabetController;
use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

Route::get('/librarians', [LibrarianController::class, 'index'])->name('librarians');

Route::get('/students', [StudentController::class, 'index'])->name('students');

Route::get('/books', [BookController::class, 'index'])->name('books');

Route::get('/authors', [AuthorController::class, 'index'])->name('authors');

Route::get('/publishing', [PublishingController::class, 'index'])->name('publishing');

# Settings

## Settings/Policy
Route::get('/settings', [PolicyController::class, 'read'])->name('settings');
Route::put('/settings', [PolicyController::class, 'update']);

## Settings/Categories
Route::get('/settings/categories', [CategoryController::class, 'read'])->name('settings.categories');
Route::get('/settings/categories/create', fn () => view('settings.category.create'))->name('settings.categories.create');
Route::get('/settings/categories/{category:name}/edit', fn () => view('settings.category.edit', ['category' => request()->category]))->name('settings.categories.edit');
Route::post('/settings/categories/create', [CategoryController::class, 'create']);
Route::put('/settings/categories/{category:name}/edit', [CategoryController::class, 'update']);
Route::delete('/settings/categories/{category:name}/delete', [CategoryController::class, 'delete'])->name('settings.categories.delete');

## Settings/Genre
Route::get('/settings/genres', [GenreController::class, 'read'])->name('settings.genres');
Route::get('/settings/genres/create', fn () => view('settings.genre.create'))->name('settings.genres.create');
Route::get('/settings/genres/{genre:name}/edit', fn () => view('settings.genre.edit', ['genre' => request()->genre]))->name('settings.genres.edit');
Route::post('/settings/genres/create', [GenreController::class, 'create']);
Route::put('/settings/genres/{genre:name}/edit', [GenreController::class, 'update']);
Route::delete('/settings/genres/{genre:name}/delete', [GenreController::class, 'delete'])->name('settings.genres.delete');

## Settings/Publisher
Route::get('/settings/publishers', [PublisherController::class, 'read'])->name('settings.publishers');
Route::get('/settings/publishers/create', fn () => view('settings.publisher.create'))->name('settings.publishers.create');
Route::get('/settings/publishers/{publisher:name}/edit', fn () => view('settings.publisher.edit', ['publisher' => request()->publisher]))->name('settings.publishers.edit');
Route::post('/settings/publishers/create', [PublisherController::class, 'create']);
Route::put('/settings/publishers/{publisher:name}/edit', [PublisherController::class, 'update']);
Route::delete('/settings/publishers/{publisher:name}/delete', [PublisherController::class, 'delete'])->name('settings.publishers.delete');

## Settings/Cover
Route::get('/settings/covers', [CoverController::class, 'read'])->name('settings.covers');
Route::get('/settings/covers/create', fn () => view('settings.cover.create'))->name('settings.covers.create');
Route::get('/settings/covers/{cover:name}/edit', fn () => view('settings.cover.edit', ['cover' => request()->cover]))->name('settings.covers.edit');
Route::post('/settings/covers/create', [CoverController::class, 'create']);
Route::put('/settings/covers/{cover:name}/edit', [CoverController::class, 'update']);
Route::delete('/settings/covers/{cover:name}/delete', [CoverController::class, 'delete'])->name('settings.covers.delete');

## Settings/Format
Route::get('/settings/formats', [FormatController::class, 'read'])->name('settings.formats');
Route::get('/settings/formats/create', fn () => view('settings.format.create'))->name('settings.formats.create');
Route::get('/settings/formats/{format:name}/edit', fn () => view('settings.format.edit', ['format' => request()->format]))->name('settings.formats.edit');
Route::post('/settings/formats/create', [FormatController::class, 'create']);
Route::put('/settings/formats/{format:name}/edit', [FormatController::class, 'update']);
Route::delete('/settings/formats/{format:name}/delete', [FormatController::class, 'delete'])->name('settings.formats.delete');

## Settings/Alphabet
Route::get('/settings/alphabets', [AlphabetController::class, 'read'])->name('settings.alphabets');
Route::get('/settings/alphabets/create', fn () => view('settings.alphabet.create'))->name('settings.alphabets.create');
Route::get('/settings/alphabets/{alphabet:name}/edit', fn () => view('settings.alphabet.edit', ['alphabet' => request()->alphabet]))->name('settings.alphabets.edit');
Route::post('/settings/alphabets/create', [AlphabetController::class, 'create']);
Route::put('/settings/alphabets/{alphabet:name}/edit', [AlphabetController::class, 'update']);
Route::delete('/settings/alphabets/{alphabet:name}/delete', [AlphabetController::class, 'delete'])->name('settings.alphabets.delete');
