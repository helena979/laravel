<?php

namespace App\Http\Controllers;

use App\Models\Kategorija;
use Illuminate\Http\Request;

class KategorijaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kategorije=Kategorija::all();
        return view ('kategorija.index',['kats'=>$kategorije]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kategorije.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
        'nazivKategorija'=>'required',
        'opisKategorija'=>'required'
        ]);
        $kategorija = new Kategorija();
        $kategorija->Naziv = $request->nazivKategorije;
        $kategorija->Opis = $request->opisKategorije;
        $kategorija = $kategorija->save();
        if($kategorija){
            return redirect()->route('kategorije.index')->with('success','Kategorija je uspjesno dodata');
        }else{
            return redirect()->route('kategorije.index')->with('fail','Kategorija nije uspjesno dodata');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kategorija  $kategorija
     * @return \Illuminate\Http\Response
     */
    public function show(Kategorija $kategorija)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kategorija  $kategorija
     * @return \Illuminate\Http\Response
     */
    public function edit(Kategorija $kategorija)
    {
        $kategorija->Kategorija::where('Id',$kategorija->Id)->first();
        return view('kategorija.edit',['kats'=>$kategorija]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kategorija  $kategorija
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kategorija $kategorija)
    {
        $request->validate([
            'nazivKategorijaEdit'=>'required',
            'opisKategorija'=>'required'

        ]);
        $kategorije=Kategorija::where('Id',$kategorija->Id)->first()->update([
            'Naziv'=>$request->nazivKategorijaEdit,
            'Opis'=>$request->opisKategorija
        ]);
        if($kategorija){
            return redirect()->route('kategorije.index')->with('success','Kategorija je uspjesno editovana');
        }else{
            return redirect()->route('kategorije.index')->with('fail','Kategorija nije uspjesno editovana');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kategorija  $kategorija
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kategorija $kategorija)
    {
        $poruka=Kategorija::where('Id',$kategorija->Id)->dalete();
        if($kategorija){
            return redirect()->route('kategorije.index')->with('success','Kategorija je uspjesno dodata');
        }else{
            return redirect()->route('kategorije.index')->with('fail','Kategorija nije uspjesno dodata');
        }
}
}